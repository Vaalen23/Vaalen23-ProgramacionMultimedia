package com.example.supergamecounter

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

class EndGameActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val username = intent.getStringExtra("username") ?: "Jugador"
        val score = intent.getIntExtra("score", 0)
        val level = intent.getIntExtra("level", 1)
        val byEndButton = intent.getBooleanExtra("byEndButton", true)

        setContent {
            EndGameScreen(username, score, level, byEndButton) {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Puntuación del jugador $username")
                    putExtra(Intent.EXTRA_TEXT, "El jugador $username ha obtenido una puntuación de $score puntos y ha alcanzado el nivel $level.")
                }
                startActivity(Intent.createChooser(sendIntent, null))
            }
        }
    }
}

@Composable
fun EndGameScreen(username: String, score: Int, level: Int, byEndButton: Boolean, onSend: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (level >= 10 && !byEndButton) {
                Text(stringResource(id = R.string.congrats_message))
            } else {
                Text(stringResource(id = R.string.end_message))
            }
            Spacer(modifier = Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.trophy),
                    contentDescription = null,
                    modifier = Modifier.size(80.dp)
                )
                Spacer(modifier = Modifier.width(20.dp))
                Button(onClick = onSend) {
                    Text(stringResource(id = R.string.send_button))
                }
            }
        }
    }
}
