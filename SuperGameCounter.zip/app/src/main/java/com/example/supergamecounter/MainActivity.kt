package com.example.supergamecounter

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val username = intent.getStringExtra("username") ?: "Jugador"
        setContent {
            GameScreen(username) { score, level, byEndButton ->
                val intent = Intent(this, EndGameActivity::class.java)
                intent.putExtra("username", username)
                intent.putExtra("score", score)
                intent.putExtra("level", level)
                intent.putExtra("byEndButton", byEndButton)
                startActivity(intent)
            }
        }
    }
}

@Composable
fun GameScreen(username: String, onEndGame: (Int, Int, Boolean) -> Unit) {
    var score by remember { mutableStateOf(0) }
    var level by remember { mutableStateOf(1) }

    val bgColor = when (level) {
        in 0..2 -> colorResource(id = R.color.red_level)
        in 3..6 -> colorResource(id = R.color.orange_level)
        else -> colorResource(id = R.color.green_level)
    }

    if (level == 10) {
        onEndGame(score, level, false)
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "${stringResource(id = R.string.welcome)} $username")
            Spacer(modifier = Modifier.height(20.dp))
            Box(
                modifier = Modifier
                    .background(bgColor)
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "${stringResource(id = R.string.score_label)}: $score")
                    Text(text = "${stringResource(id = R.string.level_label)}: $level")
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = {
                val increment = Random.nextInt(1, level + 1)
                score += increment
                level += 1
            }) {
                Text(stringResource(id = R.string.increase_button))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(onClick = {
                score -= (2 * level)
                if (score < 0) score = 0
            }) {
                Text(stringResource(id = R.string.decrease_button))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Button(onClick = {
                onEndGame(score, level, true)
            }) {
                Text(stringResource(id = R.string.end_button))
            }
            if (level == 5) {
                Spacer(modifier = Modifier.height(20.dp))
                Text(stringResource(id = R.string.good_way_message))
            }
        }
    }
}
